--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE bank;
--
-- Name: bank; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE bank WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'French_France.1252';


ALTER DATABASE bank OWNER TO postgres;

\connect bank

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent (
    id bigint NOT NULL,
    email character varying(255),
    password character varying(255),
    user_role character varying(255),
    username character varying(255),
    enabled boolean,
    locked boolean
);


ALTER TABLE public.agent OWNER TO postgres;

--
-- Name: c_professionnel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.c_professionnel (
    id bigint NOT NULL,
    enable boolean,
    client_id bigint,
    type character varying(255),
    agent_id bigint,
    amount bigint,
    numc bigint
);


ALTER TABLE public.c_professionnel OWNER TO postgres;

--
-- Name: c_standard; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.c_standard (
    id bigint NOT NULL,
    enable boolean,
    client_id bigint,
    type character varying(255),
    amount bigint,
    agent_id bigint,
    numc bigint
);


ALTER TABLE public.c_standard OWNER TO postgres;

--
-- Name: carte; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carte (
    id bigint NOT NULL,
    achata bigint,
    achatq bigint,
    retraita bigint,
    retraitq bigint,
    carte_type character varying(255),
    c_professionnel_id bigint,
    c_standard_id bigint
);


ALTER TABLE public.carte OWNER TO postgres;

--
-- Name: carte_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.carte_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.carte_id_seq OWNER TO postgres;

--
-- Name: carte_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.carte_id_seq OWNED BY public.carte.id;


--
-- Name: client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client (
    id bigint NOT NULL,
    email character varying(255),
    password character varying(255),
    user_role character varying(255),
    username character varying(255),
    cin character varying(255),
    telephone character varying(255),
    enabled boolean,
    locked boolean,
    compte_id bigint,
    image oid
);


ALTER TABLE public.client OWNER TO postgres;

--
-- Name: compte_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.compte_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.compte_sequence OWNER TO postgres;

--
-- Name: confirmation_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.confirmation_token (
    id bigint NOT NULL,
    confirmed_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone,
    expires_at timestamp(6) without time zone,
    token character varying(255),
    user_id bigint,
    client_id bigint
);


ALTER TABLE public.confirmation_token OWNER TO postgres;

--
-- Name: confirmation_token_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.confirmation_token_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.confirmation_token_sequence OWNER TO postgres;

--
-- Name: file; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file (
    id bigint NOT NULL,
    client_id bigint,
    data oid,
    file_name character varying(255),
    file_type character varying(255)
);


ALTER TABLE public.file OWNER TO postgres;

--
-- Name: file_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.file_id_seq OWNER TO postgres;

--
-- Name: file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.file_id_seq OWNED BY public.file.id;


--
-- Name: user_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_sequence OWNER TO postgres;

--
-- Name: carte id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carte ALTER COLUMN id SET DEFAULT nextval('public.carte_id_seq'::regclass);


--
-- Name: file id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file ALTER COLUMN id SET DEFAULT nextval('public.file_id_seq'::regclass);


--
-- Name: 140898; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('140898');


ALTER LARGE OBJECT 140898 OWNER TO postgres;

--
-- Name: 140899; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('140899');


ALTER LARGE OBJECT 140899 OWNER TO postgres;

--
-- Name: 140900; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('140900');


ALTER LARGE OBJECT 140900 OWNER TO postgres;

--
-- Name: 140901; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('140901');


ALTER LARGE OBJECT 140901 OWNER TO postgres;

--
-- Name: 140902; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('140902');


ALTER LARGE OBJECT 140902 OWNER TO postgres;

--
-- Name: 190042; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('190042');


ALTER LARGE OBJECT 190042 OWNER TO postgres;

--
-- Data for Name: agent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent (id, email, password, user_role, username, enabled, locked) FROM stdin;
\.
COPY public.agent (id, email, password, user_role, username, enabled, locked) FROM '$$PATH$$/3357.dat';

--
-- Data for Name: c_professionnel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.c_professionnel (id, enable, client_id, type, agent_id, amount, numc) FROM stdin;
\.
COPY public.c_professionnel (id, enable, client_id, type, agent_id, amount, numc) FROM '$$PATH$$/3361.dat';

--
-- Data for Name: c_standard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.c_standard (id, enable, client_id, type, amount, agent_id, numc) FROM stdin;
\.
COPY public.c_standard (id, enable, client_id, type, amount, agent_id, numc) FROM '$$PATH$$/3362.dat';

--
-- Data for Name: carte; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.carte (id, achata, achatq, retraita, retraitq, carte_type, c_professionnel_id, c_standard_id) FROM stdin;
\.
COPY public.carte (id, achata, achatq, retraita, retraitq, carte_type, c_professionnel_id, c_standard_id) FROM '$$PATH$$/3364.dat';

--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client (id, email, password, user_role, username, cin, telephone, enabled, locked, compte_id, image) FROM stdin;
\.
COPY public.client (id, email, password, user_role, username, cin, telephone, enabled, locked, compte_id, image) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: confirmation_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.confirmation_token (id, confirmed_at, created_at, expires_at, token, user_id, client_id) FROM stdin;
\.
COPY public.confirmation_token (id, confirmed_at, created_at, expires_at, token, user_id, client_id) FROM '$$PATH$$/3360.dat';

--
-- Data for Name: file; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.file (id, client_id, data, file_name, file_type) FROM stdin;
\.
COPY public.file (id, client_id, data, file_name, file_type) FROM '$$PATH$$/3366.dat';

--
-- Name: carte_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.carte_id_seq', 35, true);


--
-- Name: compte_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.compte_sequence', 55, true);


--
-- Name: confirmation_token_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.confirmation_token_sequence', 10, true);


--
-- Name: file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.file_id_seq', 6, true);


--
-- Name: user_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_sequence', 18, true);


--
-- Data for Name: BLOBS; Type: BLOBS; Schema: -; Owner: -
--

\i $$PATH$$/3373.dat

--
-- Name: agent agent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent
    ADD CONSTRAINT agent_pkey PRIMARY KEY (id);


--
-- Name: c_professionnel c_professionnel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_professionnel
    ADD CONSTRAINT c_professionnel_pkey PRIMARY KEY (id);


--
-- Name: c_standard c_standard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_standard
    ADD CONSTRAINT c_standard_pkey PRIMARY KEY (id);


--
-- Name: carte carte_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carte
    ADD CONSTRAINT carte_pkey PRIMARY KEY (id);


--
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (id);


--
-- Name: confirmation_token confirmation_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.confirmation_token
    ADD CONSTRAINT confirmation_token_pkey PRIMARY KEY (id);


--
-- Name: file file_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_pkey PRIMARY KEY (id);


--
-- Name: c_standard fk_387xco5xwr0ky81vf24w2hqlt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_standard
    ADD CONSTRAINT fk_387xco5xwr0ky81vf24w2hqlt FOREIGN KEY (agent_id) REFERENCES public.agent(id);


--
-- Name: c_professionnel fk_fgccvajvlbjurur78lri8hfdo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_professionnel
    ADD CONSTRAINT fk_fgccvajvlbjurur78lri8hfdo FOREIGN KEY (agent_id) REFERENCES public.agent(id);


--
-- Name: c_standard fk_h3onvdyqqb0tkmv22iebmm9a0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_standard
    ADD CONSTRAINT fk_h3onvdyqqb0tkmv22iebmm9a0 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: c_professionnel fk_jyrl2fthy2rtok68bvbn7k75h; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_professionnel
    ADD CONSTRAINT fk_jyrl2fthy2rtok68bvbn7k75h FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: confirmation_token fkek7f8a4pexih9x3kjjuqf5q1v; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.confirmation_token
    ADD CONSTRAINT fkek7f8a4pexih9x3kjjuqf5q1v FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: confirmation_token fkjegnel02ia3tkq8b7138w5lpo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.confirmation_token
    ADD CONSTRAINT fkjegnel02ia3tkq8b7138w5lpo FOREIGN KEY (user_id) REFERENCES public.agent(id);


--
-- Name: carte fks7hiuwnvh33otnnwskj8mj5ka; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carte
    ADD CONSTRAINT fks7hiuwnvh33otnnwskj8mj5ka FOREIGN KEY (c_professionnel_id) REFERENCES public.c_professionnel(id);


--
-- Name: carte fkscvxkgjda77hra9vgdxim02mp; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carte
    ADD CONSTRAINT fkscvxkgjda77hra9vgdxim02mp FOREIGN KEY (c_standard_id) REFERENCES public.c_standard(id);


--
-- PostgreSQL database dump complete
--

